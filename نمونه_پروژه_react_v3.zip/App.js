import React, { useState } from "react";

export default function Dashboard() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100">
      {!isLoggedIn ? (
        <LoginForm onLogin={() => setIsLoggedIn(true)} />
      ) : (
        <div className="p-6">
          <header className="mb-6">
            <h1 className="text-3xl font-bold text-gray-800">داشبورد معلم</h1>
            <p className="text-gray-600">ابزارهای هوشمند برای آموزش بهتر</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <ToolCard title="ایجاد آزمون هوشمند" description="ساخت آزمون بر اساس سطح دانش‌آموزان" />
            <ToolCard title="تحلیل پاسخ‌ها" description="ارائه گزارش‌های تحلیلی از آزمون‌ها" />
            <ToolCard title="پیشنهاد محتوا" description="ارائه محتوای درسی بر اساس سطح دانش‌آموز" />
          </div>
        </div>
      )}
    </div>
  );
}

function ToolCard({ title, description }) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4 hover:shadow-lg transition">
      <h2 className="text-xl font-semibold text-gray-800 mb-2">{title}</h2>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
}

function LoginForm({ onLogin }) {
  return (
    <div className="flex items-center justify-center h-screen">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          onLogin();
        }}
        className="bg-white shadow-lg rounded-xl p-8 w-full max-w-md"
      >
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-4">ورود معلم</h2>
        <input
          type="text"
          placeholder="نام کاربری"
          className="w-full p-2 mb-4 border border-gray-300 rounded-md"
          required
        />
        <input
          type="password"
          placeholder="رمز عبور"
          className="w-full p-2 mb-4 border border-gray-300 rounded-md"
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
        >
          ورود
        </button>
      </form>
    </div>
  );
}
